#include <stdio.h>
#include <stddef.h>
#include "util.h"
#include "baja_data_compression.h"
#include "csv.h"

/*
 * Serial Studio index map (1-based, matches "index" field in DAS_SerialStudio.json):
 *
 *  1  - Hour                     (no source - empty)
 *  2  - Minute                   (no source - empty)
 *  3  - Second                   (no source - empty)
 *  4  - Time from Start          (no source - empty)
 *  5  - Screenshot Flag          (no source - empty)
 *  6  - Battery Voltage          (no source - empty)
 *  7  - Battery Level            (no source - empty)
 *  8  - Accel X                  accel_data.x
 *  9  - Accel Y                  accel_data.y
 *  10 - Accel Z                  accel_data.z
 *  11 - (unused)
 *  12 - (unused)
 *  13 - (unused)
 *  14 - Latitude                 gps_pos.latitude / 100000.0
 *  15 - Longitude                gps_pos.longitude / 100000.0
 *  16 - Has Fix                  (no source - empty)
 *  17 - Num Sats                 (no source - empty)
 *  18 - Altitude                 (no source - empty)
 *  19 - Heading                  (no source - empty)
 *  20 - GPS Velocity             (no source - empty)
 *  21 - Engine RPM               cvt_data.primary
 *  22 - Secondary RPM            cvt_data.secondary
 *  23 - CVT Primary Temperature  (cvt_data.temperature - shared single temp sensor)
 *  24 - CVT Secondary Temp       (no source - empty)
 *  25 - CVT Belt Temperature     (no source - empty)
 *  26 - Front Left Wheel Speed   wheel_speeds.fl
 *  27 - Front Right Wheel Speed  wheel_speeds.fr
 *  28 - Rear Left Wheel Speed    wheel_speeds.rl
 *  29 - Rear Right Wheel Speed   wheel_speeds.rr
 *  30 - Front Left Displacement  sus_displacements.fl
 *  31 - Front Right Displacement sus_displacements.fr
 *  32 - Rear Left Displacement   sus_displacements.rl
 *  33 - Rear Right Displacement  sus_displacements.rr
 *  34 - Front Brake Pressure     pedal_data.frontPressure
 *  35 - Rear Brake Pressure      pedal_data.rearPressure
 *  36 - (unused)
 *  37 - SD Logging Active        (no source - empty)
 */

 // Helper macro: append to buf, advance pointer, shrink remaining length.
#define CSV_APPEND(fmt, ...) \
    do { \
        size_t _w = snprintf(buf, bufLen, fmt, ##__VA_ARGS__); \
        buf += _w; bufLen -= _w; \
    } while(0)

int make_csv(char* buf, size_t bufLen, const rxdata_t rxdata) {

	baja_data_t sortedData = {};
	sent_data_points_t newDataPoints = unpack_data(rxdata.data, &sortedData);

	// ---- indices 1-7: time + flags + battery (no source yet) ----
	CSV_APPEND(",,,,,,,");   // 7 empty fields → commas for idx 1..7

	// ---- indices 8-10: accelerometer ----
	if (newDataPoints & ACCEL_DATA) {
		CSV_APPEND("%i,%i,%i,",
			sortedData.accel_data.x,
			sortedData.accel_data.y,
			sortedData.accel_data.z);
	}
	else {
		CSV_APPEND(",,,");
	}

	// ---- indices 11-13: unused ----
	CSV_APPEND(",,,");

	// ---- indices 14-15: GPS lat/lon ----
	if (newDataPoints & GPS_LAT_LONG) {
		CSV_APPEND("%.6f,%.6f,",
			sortedData.gps_pos.latitude / 100000.0f,
			sortedData.gps_pos.longitude / 100000.0f);
	}
	else {
		CSV_APPEND(",,");
	}

	// ---- indices 16-20: GPS status fields (no source yet) ----
	CSV_APPEND(",,,,,");

	// ---- indices 21-22: CVT RPM ----
	if (newDataPoints & CVT_DATA) {
		CSV_APPEND("%u,%u,",
			sortedData.cvt_data.primary,
			sortedData.cvt_data.secondary);
	}
	else {
		CSV_APPEND(",,");
	}

	// ---- index 23: CVT temperature (mapped to "CVT Primary Temperature") ----
	// ---- indices 24-25: no second/belt temp sensor yet ----
	if (newDataPoints & CVT_DATA) {
		CSV_APPEND("%u,",
			sortedData.cvt_data.temperature);
	}
	else {
		CSV_APPEND(",");
	}
	CSV_APPEND(",,");   // idx 24, 25 empty

	// ---- indices 26-29: wheel speeds ----
	if (newDataPoints & WHEEL_SPEEDS) {
		CSV_APPEND("%u,%u,%u,%u,",
			sortedData.wheel_speeds.fl,
			sortedData.wheel_speeds.fr,
			sortedData.wheel_speeds.rl,
			sortedData.wheel_speeds.rr);
	}
	else {
		CSV_APPEND(",,,,");
	}

	// ---- indices 30-33: suspension displacements ----
	if (newDataPoints & SUS_DISPLACEMENTS) {
		CSV_APPEND("%u,%u,%u,%u,",
			sortedData.sus_displacements.fl,
			sortedData.sus_displacements.fr,
			sortedData.sus_displacements.rl,
			sortedData.sus_displacements.rr);
	}
	else {
		CSV_APPEND(",,,,");
	}

	// ---- indices 34-35: brake pressures ----
	if (newDataPoints & PEDAL_DATA) {
		CSV_APPEND("%u,%u,",
			sortedData.pedal_data.frontPressure,
			sortedData.pedal_data.rearPressure);
	}
	else {
		CSV_APPEND(",,");
	}

	// ---- index 36: unused, index 37: SD logging (no source yet) ----
	// No trailing comma after the last field — Serial Studio splits on commas,
	// and a trailing comma would create a spurious extra empty column.
	CSV_APPEND(",");    // idx 36 empty, idx 37 empty (no trailing comma needed after 37)

	return 1;
}